package com.cg.service;

import java.util.List;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotel;
import com.cg.bean.RoomDetails;
import com.cg.bean.Users;
import com.cg.dao.BookingDAOImpl;
import com.cg.dao.IBookingDAO;
import com.cg.exception.BookingException;

public class BookingServiceImpl implements IBookingService{

	IBookingDAO dao;
	
	public BookingServiceImpl() {
		dao = new BookingDAOImpl();
	}
	@Override
	public boolean validateDetails(Users user) throws BookingException{
		
		return dao.validateDetails(user);
	}

	@Override
	public String addUser(Users user) throws BookingException{
		
		return dao.addUser(user);
	}

	@Override
	public boolean validateUser(String mobileNo, String password)
			throws BookingException {
		
		return dao.validateUser(mobileNo, password);
	}

	@Override
	public List<Hotel> viewAllHotels() throws BookingException {
		
		return dao.viewAllHotels();
	}

	@Override
	public List<RoomDetails> getAllRooms(String hotelId)
			throws BookingException {
		
		return dao.getAllRooms(hotelId);
	}

	@Override
	public BookingDetails addBookingDetails(BookingDetails bookingDetails)
			throws BookingException {
		
		return dao.addBookingDetails(bookingDetails);
	}

	@Override
	public BookingDetails viewBookingDetails(String bookingId)
			throws BookingException {
		
		return dao.viewBookingDetails(bookingId);
	}

	

}
